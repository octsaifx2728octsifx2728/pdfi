<?php 

$config->paths=array(

 	"urlbase"=>"http://e-spacios.local",
 	"surlbase"=>"http://e-spacios.local",
 	"base"=>"/var/www/e-spacios.com/",
	"core"=>"/var/www/e-spacios.com/core/",
	"hooks"=>"/var/www/e-spacios.com/hooks/",
	"core/class"=>"/var/www/e-spacios.com/core/class/",
	"core/languajes"=>"/var/www/e-spacios.com/core/languajes/",
	"core/interfaces"=>"/var/www/e-spacios.com/core/interfaces/",
	"html"=>"/var/www/e-spacios.com/html/",
	"chunks"=>"/var/www/e-spacios.com/chunks/",
	"chunks_mobile"=>"/var/www/e-spacios.com/chunks_mobile/",
	"chunks/html"=>"/var/www/e-spacios.com/chunks/html/",
	"chunks_mobile/html"=>"/var/www/e-spacios.com/chunks_mobile/html/",
	"chunks_tablet/html"=>"/var/www/e-spacios.com/chunks_tablet/html/",
	"app"=>"/var/www/e-spacios.com/apps/",
	"preload"=>"/var/www/e-spacios.com/preload/",
	"avatars"=>"/var/www/e-spacios.com/galeria/perfil/",
	"fotos"=>"/var/www/e-spacios.com/galeria/imagenes/",
	"handlers"=>"/var/www/e-spacios.com/handlers/",
/*

	"base"=>"/home/kosa/www/e-spacios/",
	"core"=>"/home/kosa/www/e-spacios/core/",
	"core/class"=>"/home/kosa/www/e-spacios/core/class/",
	"core/languajes"=>"/home/kosa/www/e-spacios/core/languajes/",
	"core/interfaces"=>"/home/kosa/www/e-spacios/core/interfaces/",
	"html"=>"/home/kosa/www/e-spacios/html/",
	"chunks"=>"/home/kosa/www/e-spacios/chunks/",
	"chunks/html"=>"/home/kosa/www/e-spacios/chunks/html/",
	"app"=>"/home/kosa/www/e-spacios/apps/",
	"preload"=>"/home/kosa/www/e-spacios/preload/",
	"avatars"=>"/home/kosa/www/e-spacios/galeria/perfil/",
	"fotos"=>"/home/kosa/www/e-spacios/galeria/imagenes/",
	"handlers"=>"/home/kosa/www/e-spacios/handlers/",	
*/

	
	"clean"=>array(
		array(
			"path"=>"/var/www/vhosts/e-spacios.com/httpdocs/cache/",
			"recursive"=>true
			),
		array(
			"path"=>"/var/www/vhosts/e-spacios.com/httpdocs/preload/",
			"recursive"=>true
			)
		)
	);

