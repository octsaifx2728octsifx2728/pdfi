<?php

$config->defaults=array(
	"lang"=>"es",
	"doctype"=>"html5",
	"charset"=>"utf-8",
	"currency"=>"MXN",
	"currency_default"=>"MXN",
	"mail"=>array("Nombre"=>"e-spacios.com","Mail"=>"mailer@e-spacios.com")
	);

$config->defaults["namespaces"]=array(
      "xmlns"=>"http://www.w3.org/1999/xhtml",
      "xmlns:og"=>"http://ogp.me/ns#",
      "xmlns:fb"=>"http://www.facebook.com/2008/fbml");

$config->defaults["facebook"]=(object)array(
      "app_id"=>"344869598922016",
      "app_secret"=>"3c89ca674be6e29600a139dfc7441c0e",
      "app_token"=>"344869598922016|uLYFHatCv9uSZd0frxT6scqcP24");


$config->defaults["linkedin"]=(object)array(
      "client_id"=>"b1y9walm3ty6",
      "scope"=>"r_emailaddress",
      "client_secret"=>"NBGqPEARKeutJEE1");