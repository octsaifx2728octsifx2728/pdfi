<?php 

$config->paths=array(

 	"urlbase"=>		"http://www.e-spacios.com",
 	"surlbase"=>		"https://www.e-spacios.com",
 	"base"=>		"/var/www/vhosts/e-spacios.com/httpdocs/",
	"core"=>		"/var/www/vhosts/e-spacios.com/httpdocs/core/",
	"hooks"=>		"/var/www/vhosts/e-spacios.com/httpdocs/hooks/",
	"core/class"=>		"/var/www/vhosts/e-spacios.com/httpdocs/core/class/",
	"core/languajes"=>	"/var/www/vhosts/e-spacios.com/httpdocs/core/languajes/",
	"core/interfaces"=>	"/var/www/vhosts/e-spacios.com/httpdocs/core/interfaces/",
	"html"=>		"/var/www/vhosts/e-spacios.com/httpdocs/html/",
	"chunks"=>		"/var/www/vhosts/e-spacios.com/httpdocs/chunks/",
	"chunks_mobile"=>	"/var/www/vhosts/e-spacios.com/httpdocs/chunks_mobile/",
	"chunks_tablet"=>	"/var/www/vhosts/e-spacios.com/httpdocs/chunks_tablet/",
	"chunks/html"=>		"/var/www/vhosts/e-spacios.com/httpdocs/chunks/html/",
	"chunks_mobile/html"=>	"/var/www/vhosts/e-spacios.com/httpdocs/chunks_mobile/html/",
	"chunks_tablet/html"=>	"/var/www/vhosts/e-spacios.com/httpdocs/chunks_tablet/html/",
	"app"=>			"/var/www/vhosts/e-spacios.com/httpdocs/apps/",
	"preload"=>		"/var/www/vhosts/e-spacios.com/httpdocs/preload/",
	"avatars"=>		"/var/www/vhosts/e-spacios.com/httpdocs/galeria/perfil/",
	"fotos"=>		"/var/www/vhosts/e-spacios.com/httpdocs/galeria/imagenes/",
	"handlers"=>		"/var/www/vhosts/e-spacios.com/httpdocs/handlers/",
/*

	"base"=>"/home/kosa/www/e-spacios/",
	"core"=>"/home/kosa/www/e-spacios/core/",
	"core/class"=>"/home/kosa/www/e-spacios/core/class/",
	"core/languajes"=>"/home/kosa/www/e-spacios/core/languajes/",
	"core/interfaces"=>"/home/kosa/www/e-spacios/core/interfaces/",
	"html"=>"/home/kosa/www/e-spacios/html/",
	"chunks"=>"/home/kosa/www/e-spacios/chunks/",
	"chunks/html"=>"/home/kosa/www/e-spacios/chunks/html/",
	"app"=>"/home/kosa/www/e-spacios/apps/",
	"preload"=>"/home/kosa/www/e-spacios/preload/",
	"avatars"=>"/home/kosa/www/e-spacios/galeria/perfil/",
	"fotos"=>"/home/kosa/www/e-spacios/galeria/imagenes/",
	"handlers"=>"/home/kosa/www/e-spacios/handlers/",	
*/

	
	"clean"=>array(
		array(
			"path"=>"/var/www/vhosts/e-spacios.com/httpdocs/cache/",
			"recursive"=>true
			),
		array(
			"path"=>"/var/www/vhosts/e-spacios.com/httpdocs/preload/",
			"recursive"=>true
			)
		)
	);

